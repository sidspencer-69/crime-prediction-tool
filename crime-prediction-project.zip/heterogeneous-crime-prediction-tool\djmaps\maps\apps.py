from django.apps import AppConfig


class MapsConfig(AppConfig):
    name = 'maps'
