from django.apps import AppConfig


class CrimepredConfig(AppConfig):
    name = 'crimePred'
