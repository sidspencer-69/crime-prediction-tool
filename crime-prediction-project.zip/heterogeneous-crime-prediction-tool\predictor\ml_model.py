import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from datetime import datetime
import joblib

class CrimePredictionModel:
    def __init__(self):
        self.model = RandomForestClassifier(
            n_estimators=100,
            max_depth=10,
            random_state=42
        )
        self.location_encoder = LabelEncoder()
        self.risk_levels = ['Low', 'Medium', 'High']

    def preprocess_input(self, location, date, time):
        # Convert date and time to features
        dt = datetime.strptime(f"{date} {time}", "%Y-%m-%d %H:%M")
        hour = dt.hour
        day_of_week = dt.weekday()
        month = dt.month
        is_weekend = 1 if day_of_week >= 5 else 0
        is_night = 1 if (hour >= 20 or hour <= 5) else 0

        # Encode location
        location_encoded = self.location_encoder.fit_transform([location])[0]

        return np.array([[
            location_encoded,
            hour,
            day_of_week,
            month,
            is_weekend,
            is_night
        ]])

    def train(self, sample_data=None):
        if sample_data is None:
            # Sample training data (replace with real data)
            sample_data = {
                'location': ['Downtown', 'Suburb', 'City Center'] * 100,
                'hour': np.random.randint(0, 24, 300),
                'day_of_week': np.random.randint(0, 7, 300),
                'month': np.random.randint(1, 13, 300),
                'is_weekend': np.random.randint(0, 2, 300),
                'is_night': np.random.randint(0, 2, 300),
                'risk_level': np.random.randint(0, 3, 300)  # 0: Low, 1: Medium, 2: High
            }
            
        df = pd.DataFrame(sample_data)
        
        # Encode locations
        df['location_encoded'] = self.location_encoder.fit_transform(df['location'])
        
        # Train the model
        X = df[['location_encoded', 'hour', 'day_of_week', 'month', 'is_weekend', 'is_night']]
        y = df['risk_level']
        
        self.model.fit(X, y)
        
    def predict(self, location, date, time):
        # Preprocess input
        X = self.preprocess_input(location, date, time)
        
        # Make prediction
        risk_level_idx = self.model.predict(X)[0]
        risk_level = self.risk_levels[risk_level_idx]
        
        # Calculate confidence scores
        probabilities = self.model.predict_proba(X)[0]
        confidence = float(max(probabilities) * 100)
        
        # Get feature importance for explanation
        feature_importance = dict(zip(
            ['Location', 'Hour', 'Day of Week', 'Month', 'Weekend', 'Night Time'],
            self.model.feature_importances_
        ))
        
        return {
            'risk_level': risk_level,
            'confidence': confidence,
            'feature_importance': feature_importance,
            'location': location,
            'date': date,
            'time': time
        }

    def save_model(self, path='crime_model.pkl'):
        joblib.dump({
            'model': self.model,
            'location_encoder': self.location_encoder
        }, path)

    def load_model(self, path='crime_model.pkl'):
        data = joblib.load(path)
        self.model = data['model']
        self.location_encoder = data['location_encoder']