from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth.forms import UserCreationForm
from .ml_model import CrimePredictionModel

# Initialize the model
model = CrimePredictionModel()
model.train()  # Train with sample data

def home(request):
    return render(request, 'home.html')

def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=password)
            login(request, user)
            return redirect('predict')
    else:
        form = UserCreationForm()
    return render(request, 'signup.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('predict')
    return render(request, 'login.html')

@login_required
def predict(request, location=None):
    if request.method == 'POST':
        location = request.POST.get('location')
        time = request.POST.get('time')
        date = request.POST.get('date')
        
        prediction = {
            'risk_level': 'Medium',
            'confidence': 75.5,
            'location': location,
            'date': date,
            'time': time,
            'feature_importance': {
                'keys': ['Location', 'Time', 'Date'],
                'values': [40, 35, 25]
            }
        }
        return render(request, 'predict.html', {'prediction': prediction})
    return render(request, 'predict.html', {'location': location} if location else {})

@login_required
def profile(request):
    return render(request, 'profile.html')